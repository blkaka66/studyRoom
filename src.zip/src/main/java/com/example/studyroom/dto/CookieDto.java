package com.example.studyroom.dto;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

public class CookieDto {
    public CookieDto() {
    }
    private String shopId;
}
