package com.example.studyroom.model;

public enum TicketTypeEnum {
    PERIOD, // 기간권
    TIME    // 시간권
}
