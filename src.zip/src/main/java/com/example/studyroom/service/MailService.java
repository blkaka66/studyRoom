package com.example.studyroom.service;

public interface MailService {
    void sendEmail(String toEmail, String title, String text);
}
