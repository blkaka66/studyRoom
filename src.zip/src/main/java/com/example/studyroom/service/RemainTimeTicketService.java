package com.example.studyroom.service;

import com.example.studyroom.model.RemainTimeTicketEntity;

public interface RemainTimeTicketService extends BaseService<RemainTimeTicketEntity> {

}
