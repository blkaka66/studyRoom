package com.example.studyroom.repository;

public class BaseRepository {
}
