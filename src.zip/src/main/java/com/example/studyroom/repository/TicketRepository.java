//package com.example.studyroom.repository;
//
//import com.example.studyroom.model.TicketEntity;
//import org.springframework.data.jpa.repository.JpaRepository;
//
//import java.util.List;
//
//public interface TicketRepository <T extends TicketEntity> extends JpaRepository<T, Long> {
//    List<T> findByShopId(Long shopId);
//}
